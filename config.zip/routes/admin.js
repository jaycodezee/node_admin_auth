const express = require('express');
const router = express.Router();
const { signup, login, forgotPassword, changePassword ,emailforgot} = require('../controllers/adminController');


router.post('/signup', signup);
router.post('/login', login);
router.post('/forgot-password', forgotPassword);
router.post('/change-password', changePassword);
router.post('/reset-password/:token', emailforgot);

module.exports = router;