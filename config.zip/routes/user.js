const express = require('express');
const router = express.Router();
const { addUser, deleteUser ,getUsersByAdmin,updateUser,getUserById} = require('../controllers/adminuserController');
const {restrictToLoggedinUserOnly} = require('../middleware/authMiddleware');

router.post('/add-user', addUser);
router.delete('/delete-user/:id', deleteUser);
router.get('/users/:adminId', getUsersByAdmin);
router.put('/users/:id', updateUser);
router.get('/user/:id', getUserById);

module.exports = router;