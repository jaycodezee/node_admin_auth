// routes/invitationRoutes.js

const express = require('express');
const router = express.Router();
const { sendInvitation, getInvitationsByUser } = require('../controllers/invitationController');

router.post('/invitations', sendInvitation);
router.get('/invitations/:userId', getInvitationsByUser);

module.exports = router;
