const express = require('express');
const router = express.Router();
const{createEvent,deleteEvent , updateEvent , listEvents,getEventById} = require('../controllers/eventController');


router.post('/events',  createEvent);
router.delete('/delete-event/:id',  deleteEvent);
// router.get('/event/:eventId', getUsersByAdmin);
router.put('/event/:id', updateEvent);
router.get('/events', listEvents)
router.get('/events/:id', getEventById);

module.exports = router;
