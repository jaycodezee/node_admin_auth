const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');

async function restrictToLoggedinUserOnly(req, res, next) {
  try {
    const token = req.cookies?.token;
    
    if (!token) {
      return res.status(401).json({ message: 'Authorization header is missing' });
    }

    const decoded = jwt.verify(token, 'your_jwt_secret');
    const user = await Admin.findByPk(decoded.id);

    if (!user) {
      return res.status(401).json({ message: 'Invalid token' });
    }

    req.user = user;
    next();
  } catch (error) {
    console.error(error);
    res.status(401).json({ message: 'Invalid token' });
  }
}

module.exports = {
  restrictToLoggedinUserOnly,
};
